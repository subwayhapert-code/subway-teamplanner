import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const file=process.argv[2];if(!file)throw Error('Geef het pad naar een teamplanner-back-up.json op.');
const data=JSON.parse(readFileSync(file,'utf8'));
if(data.format!=='teamplanner-backup-v1'||![data.people,data.responses,data.settings].every(Array.isArray))throw Error('Dit is geen geldig back-upbestand.');
const dir=path.resolve(process.env.DATA_DIR||path.join(root,'data'));mkdirSync(dir,{recursive:true});const db=new DatabaseSync(path.join(dir,'planner.sqlite'));
db.exec('PRAGMA foreign_keys=ON');
if(!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='people'").get())throw Error('Start de app eerst eenmaal om de database klaar te maken.');
if(db.prepare('SELECT count(*) as n FROM people').get().n||db.prepare('SELECT count(*) as n FROM responses').get().n||db.prepare('SELECT count(*) as n FROM settings').get().n)throw Error('De database bevat al gegevens. Herstel is gestopt; niets is overschreven.');
db.exec('BEGIN IMMEDIATE');try{
 for(const p of data.people){if(typeof p.id!=='string'||!/^[a-f0-9]{64}$/.test(p.id)||typeof p.name!=='string'||!p.name.trim()||p.name.length>80||typeof p.created!=='string')throw Error('Ongeldig teamlid.');db.prepare('INSERT INTO people VALUES(?,?,?)').run(p.id,p.name,p.created)}
 for(const r of data.responses){if(typeof r.person!=='string'||typeof r.week!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(r.week)||typeof r.days!=='string'||typeof r.note!=='string'||typeof r.updated!=='string')throw Error('Ongeldige beschikbaarheid.');const days=JSON.parse(r.days);if(!Array.isArray(days)||days.length!==7||!days.every(d=>d&&['yes','no','unknown'].includes(d.status)&&Array.isArray(d.slots)&&d.slots.every(s=>s&&typeof s.start==='string'&&typeof s.end==='string')))throw Error('Ongeldige weekgegevens.');db.prepare('INSERT INTO responses VALUES(?,?,?,?,?)').run(r.person,r.week,r.days,r.note,r.updated)}
 for(const s of data.settings){if(s.id!=='main'||typeof s.invite!=='string'||!/^[a-f0-9]{64}$/.test(s.invite))throw Error('Ongeldige instellingen.');db.prepare('INSERT INTO settings VALUES(?,?)').run(s.id,s.invite)}
 db.exec('COMMIT');console.log('Back-up hersteld. Controleer de weekgegevens en persoonlijke links.');
}catch(e){db.exec('ROLLBACK');throw e}finally{db.close()}
