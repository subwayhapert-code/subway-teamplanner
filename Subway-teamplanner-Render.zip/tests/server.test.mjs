import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import net from 'node:net';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
test('authentication, single-owner setup, privacy, data durability and rate limiting',{timeout:60000},async()=>{
 const dir=mkdtempSync(path.join(tmpdir(),'teamplanner-test-'));const setup=randomBytes(32).toString('hex'),recovery=randomBytes(32).toString('hex');
 const socket=net.createServer();await new Promise(r=>socket.listen(0,'127.0.0.1',r));const port=socket.address().port;await new Promise(r=>socket.close(r));
 let child;const password='Lange testzin voor beheerder 2026!';let adminCookie='';
 async function start(storageDir=dir){child=spawn(process.execPath,['server.mjs'],{cwd:root,env:{...process.env,HOST:'127.0.0.1',PORT:String(port),DATA_DIR:storageDir,ADMIN_SETUP_TOKEN:setup,ADMIN_RECOVERY_TOKEN:recovery,NODE_ENV:'production',APP_ORIGIN:'https://planner.example'},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Server startup timeout')),10000);child.stderr.on('data',d=>process.stderr.write(d));child.stdout.on('data',d=>{if(String(d).includes('listening')){clearTimeout(timer);resolve()}});child.once('exit',code=>{clearTimeout(timer);reject(Error('Server exited '+code))})});}
 async function stop(){if(child&&child.exitCode===null&&!child.signalCode&&!child.killed){const ended=new Promise(r=>child.once('exit',r));child.kill();await ended}}
 async function api(route,body,headers={}){const r=await fetch(`http://127.0.0.1:${port}${route}`,{method:body?'POST':'GET',headers:{...(body?{'Content-Type':'application/json',Origin:'https://planner.example'}:{}),...headers},...(body?{body:JSON.stringify(body)}:{})});const data=await r.json();return {status:r.status,data,cookie:r.headers.get('set-cookie'),headers:r.headers}}
 try{
  await start();
  assert.equal((await api('/health')).status,200);
  assert.equal((await api('/api/planner?view=admin&week=2026-11-09')).status,401);
  assert.equal((await api('/api/planner?view=admin&week=2026-11-09',undefined,{'oai-authenticated-user-email':'owner@example.test','oai-authenticated-user-id':'owner'})).status,401);
  assert.equal((await api('/api/admin',{action:'setup',email:'owner@example.test',password,code:'guess'})).status,403);
  assert.equal((await api('/api/admin')).data.configured,false);
  const initialized=await api('/api/admin',{action:'setup',email:'owner@example.test',password,code:setup});assert.equal(initialized.status,200);adminCookie=initialized.cookie.split(';')[0];assert.match(initialized.cookie,/HttpOnly/);assert.match(initialized.cookie,/Secure/);assert.match(initialized.cookie,/SameSite=Strict/);assert.match(initialized.cookie,/__Host-team-admin=/);
  assert.equal((await api('/api/admin',{action:'setup',email:'attacker@example.test',password,code:setup})).status,409);
  assert.equal((await api('/api/admin',{action:'login',email:'owner@example.test',password:'incorrect'})).status,401);
  assert.equal((await api('/api/admin',{action:'login',email:'stranger@example.test',password})).status,401);
  assert.equal((await api('/api/admin',{action:'login',email:'owner@example.test',password},{Origin:'https://attacker.example'})).status,403);
  assert.equal((await api('/api/planner',{action:'invite'})).status,401);
  const invite=(await api('/api/planner',{action:'invite'},{Cookie:adminCookie})).data.invite;assert.match(invite,/^[a-f0-9]{64}$/);
  assert.equal((await api('/api/planner',{action:'join',name:'Wrong',invite:'guess'})).status,403);
  const member=await api('/api/planner',{action:'join',name:'Team Test',invite});const memberHeaders={Authorization:'Bearer '+member.data.token};
  assert.equal((await api('/api/planner?view=admin&week=2026-11-09',undefined,memberHeaders)).status,401);
  assert.equal((await api('/api/admin',{action:'setup',email:'team@example.test',password,code:invite})).status,403);
  const days=Array.from({length:7},()=>({status:'no',slots:[]}));days[0]={status:'yes',slots:[{start:'09:00',end:'12:00'},{start:'13:00',end:'17:00'}]};
  assert.equal((await api('/api/planner',{action:'save',week:'2026-11-09',days,note:'Test'},memberHeaders)).status,200);
  assert.deepEqual((await api('/api/planner?week=2026-11-09',undefined,memberHeaders)).data.response.days,days);
  assert.equal((await api('/api/planner?week=2026-11-16',undefined,memberHeaders)).data.response,null);
  const overlap=structuredClone(days);overlap[0].slots[1].start='11:00';assert.equal((await api('/api/planner',{action:'save',week:'2026-11-09',days:overlap,note:''},memberHeaders)).status,400);
  assert.equal((await api('/api/backup',undefined,memberHeaders)).status,401);
  const backup=await api('/api/backup',undefined,{Cookie:adminCookie});assert.equal(backup.data.people.length,1);assert.equal(backup.data.admin_users,undefined);assert.equal(backup.data.responses.length,1);
  await stop();await start();
  assert.deepEqual((await api('/api/planner?week=2026-11-09',undefined,memberHeaders)).data.response.days,days);
  assert.equal((await api('/api/planner?view=admin&week=2026-11-09',undefined,{Cookie:adminCookie})).data.people.length,1);
  assert.equal((await api('/api/admin',{action:'logout'},{Cookie:adminCookie})).status,200);
  assert.equal((await api('/api/planner?view=admin&week=2026-11-09',undefined,{Cookie:adminCookie})).status,401);
  const login=await api('/api/admin',{action:'login',email:'owner@example.test',password});assert.equal(login.status,200);adminCookie=login.cookie.split(';')[0];
  const newPassword='Nieuw sterk wachtwoord voor test 2026';
  assert.equal((await api('/api/admin',{action:'reset',code:'wrong',password:newPassword})).status,403);
  assert.equal((await api('/api/admin',{action:'reset',code:recovery,password:newPassword})).status,200);
  assert.equal((await api('/api/admin',{action:'reset',code:recovery,password})).status,403);
  assert.equal((await api('/api/planner?view=admin&week=2026-11-09',undefined,{Cookie:adminCookie})).status,401);
  assert.equal((await api('/api/admin',{action:'login',email:'owner@example.test',password})).status,401);
  const relog=await api('/api/admin',{action:'login',email:'owner@example.test',password:newPassword});assert.equal(relog.status,200);const replacementCookie=relog.cookie.split(';')[0];
  const changed=await api('/api/admin',{action:'password',currentPassword:newPassword,password:'Nog een sterk nieuw wachtwoord!'}, {Cookie:replacementCookie});assert.equal(changed.status,200);
  assert.equal((await api('/api/planner?view=admin&week=2026-11-09',undefined,{Cookie:replacementCookie})).status,401);
  let limited;for(let i=0;i<31;i++){limited=await api('/api/admin',{action:'setup',email:'x@example.test',password,code:'bad'});if(limited.status===429)break}assert.equal(limited.status,429);
  await stop();const db=new DatabaseSync(path.join(dir,'planner.sqlite'));const row=db.prepare('SELECT * FROM admin_users').get();assert.match(row.password_hash,/^scrypt:/);assert.ok(!row.password_hash.includes(password));assert.equal(db.prepare('SELECT count(*) as n FROM admin_users').get().n,1);db.close();
  const restored=path.join(dir,'restored');await start(restored);await stop();
  const backupPath=path.join(dir,'backup.json');writeFileSync(backupPath,JSON.stringify(backup.data));
  const restore=()=>spawnSync(process.execPath,['scripts/restore.mjs',backupPath],{cwd:root,env:{...process.env,DATA_DIR:restored},encoding:'utf8'});
  assert.equal(restore().status,0);assert.notEqual(restore().status,0);
  const restoredDb=new DatabaseSync(path.join(restored,'planner.sqlite'));assert.equal(restoredDb.prepare('SELECT count(*) as n FROM people').get().n,1);assert.equal(restoredDb.prepare('SELECT count(*) as n FROM responses').get().n,1);assert.equal(restoredDb.prepare('SELECT count(*) as n FROM admin_users').get().n,0);restoredDb.close();
 }finally{await stop();if(path.dirname(dir)===path.resolve(tmpdir())&&path.basename(dir).startsWith('teamplanner-test-'))rmSync(dir,{recursive:true,force:true})}
});


