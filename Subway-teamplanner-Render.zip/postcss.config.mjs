export default { plugins: {} };
